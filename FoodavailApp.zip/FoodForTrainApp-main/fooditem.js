const foodItem= [
    {
    id: 1,
    name: 'Biryani',
    category : 'biryani',
    rating : 4.3,
    price: 13,
    img :"Biryani.jpeg",
    quantity: 1
},
{
    id: 2,
    name: 'Hyderabadi Biryani',
    category : 'biryani',
    rating : 4.3,
    price: 15,
    img: "Hyderabad Biryani.jpeg",
    quantity: 1
},
{
    id: 3,
    name: 'Egg Biryani',
    category : 'biryani',
    rating : 4.3,
    price: 18,
    img: 'Egg Biryani.jpeg',
    quantity: 1
},
{
    id: 4,
    name: 'Goan Fish Biryani',
    category : 'biryani',
    rating : 4.3,
    price: 15,
    img: 'Goan Fish Biryani.jpeg',
    quantity: 1
},
{
    id: 5,
    name: 'Mutton Biryani',
    category : 'biryani',
    rating : 4.3,
    price: 10,
    img: 'Mutton Biryani.jpeg',
    quantity: 1
},
{ity: 1
},

{
    id: 6,
    name: 'Chicken Roast',
    category : 'chicken',
    rating : 4.3,
    price: 11,
    img: 'Chicken Roast .jpeg',
    quantity: 1
},
{
    id: 7,
    name: 'Chicken Curry',
    category : 'chicken',
    rating : 4.3,
    price: 10,
    img: 'Chicken Curry.png',
    quantity: 1
},
{
    id: 8,
    name: 'Matar Paneer',
    category : 'paneer',
    rating : 4.3,
    price: 15,
    img: 'Muter Paneer.jpeg',
    quantity: 1

},
{
    id: 9,
    name: 'Palak Paneer',
    category : 'paneer',
    rating : 4.3,
    price: 10,
    img: 'Palak Paneer.png',
    quantity: 1
},
{
    id: 10,
    name: 'Paneer Butter Masala',
    category : 'paneer',
    rating : 4.3,
    price: 15,
    img: 'Paneer Butter Masala.jpeg',
    quantity: 1

},

{
    id: 11,
    name: 'Navratan Korma',
    category : 'vegetable',
    rating : 4.3,
    price: 8,
    img: 'Navaratan Korma.jpeg',
    quantity: 1
},
{
    id: 12,
    name: 'Veg Jalfrezi',
    category : 'vegetable',
    rating : 4.3,
    price: 7,
    img: 'Veg Jalfrezi.jpeg',
    quantity: 1
},
{
    id: 13,
    name: 'Veg Biryani',
    category : 'vegetable',
    rating : 4.3,
    price: 5,
    img: 'Veg Biryani.jpeg',
    quantity: 1
},

{
    id: 14,
    name: 'Momos',
    category : 'chinese',
    rating : 4.3,
    price: 8,
    img: 'Momos.jpeg',
    quantity: 1
},
{
    id: 15,
    name: 'Chicken Manchurian',
    category : 'chinese',
    rating : 4.3,
    price: 7,
    img: 'Chicken Manchurian.jpeg',
    quantity: 1
},
{
    id: 16,
    name: 'Chili Chicken',
    category : 'chinese',
    rating : 4.3,
    price: 5,
    img: 'Chilli Chicken.png',
    quantity: 1
},

{
    id: 17,
    name: 'Butter Masala Dosa',
    category : 'south indian',
    rating : 4.3,
    price: 18,
    img: 'Butter Masala Dosa.jpeg',
    quantity: 1
},
{
    id: 18,
    name: 'Idli',
    category : 'south indian',
    rating : 4.3,
    price: 20,
    img: 'Idli.jpeg',
    quantity: 1
},
{
    id: 19,
    name: 'Masala Dosa',
    category : 'south indian',
    rating : 4.3,
    price: 12,
    img: 'Masala Dosa.png',
    quantity: 1
},

   
]

export {foodItem};